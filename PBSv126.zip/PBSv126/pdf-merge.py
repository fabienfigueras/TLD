from pypdf import PdfWriter

#OutputFile="Abacus-Ruger-308_GGG_175.pdf"
#
OutputFile="Abacus-Sabatti-308_Sako_175.pdf"
#OutputFile="Abacus-Tikka-308_GGG_190.pdf"
#OutputFile="Abacus-CZ457MDT-22LR_Norma_43.pdf"

#Str1="Abacus-308_GGG_175_"
#
Str1="Abacus-308_Sako_175_"
#Str1="Abacus-308_GGG_190_"
#Str1="Abacus-224_Norma_43_"

Str2=".pdf"
Dist=100
i=0
pdfs = []

#
while Dist <= 1600:
#while Dist <= 600:
	FileName= Str1+str(Dist)+Str2
	pdfs.append(FileName)
#	print("FileNAme [",i,"] = ",pdfs[i])
	Dist += 100
	i+=1

# merger = PdfMerger()

print(" Merging pdfs...")

merger = PdfWriter()

for pdf in pdfs:
    merger.append(pdf)

merger.write(OutputFile)
merger.close()
