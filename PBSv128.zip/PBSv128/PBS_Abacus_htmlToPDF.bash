#!/bin/bash

Echo "PBS Abacus html files conversion to pdf"

Str0="python3 h2p-v100.py"
#Str1=" Abacus-308_GGG_175_"
#
Str1=" Abacus-308_Sako_175_"
#Str1=" Abacus-308_GGG_190_"
#Str1=" Abacus-224_Norma_43_"

Str2="_2024-10-02.html"

#Str3=" Abacus-308_GGG_175_"
#
Str3=" Abacus-308_Sako_175_"
#Str3=" Abacus-308_GGG_190_"
#Str3=" Abacus-224_Norma_43_"

Str4=".pdf"

Dist=100

echo "#!/bin/bash" >./PBS_Abacus_HTML2PDF.bsh

#
while [ $Dist -le 1600 ]
#while [ $Dist -le 600 ]
do

Cmd="$Str0$Str1$(printf "%d" $Dist)$Str2$Str3$(printf "%d" $Dist)$Str4"
echo $Cmd
echo $Cmd >>./PBS_Abacus_HTML2PDF.bsh
echo "wait" >>./PBS_Abacus_HTML2PDF.bsh

Dist=$[$Dist+100]
done
