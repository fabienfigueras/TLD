#!/bin/bash

Echo "PBS Abacus Creation"

Str1="python3 ./PBS-v126.py 0.224 43 800 "
#Str2=" 0 N 0 2 N 0.001 N 0 N G1 1 Y"
#Str2=" 0 N 0 2 N 0.01 N 0 N G7 0 Y"
#
Str2=" 0 N 0 2 N 0.001 N 0 N G7 0 Y"
Dist=100

echo "#!/bin/bash" >./PBS_Abacus_Creation.bsh

#
while [ $Dist -le 1600 ]
#while [ $Dist -le 600 ]
do

Cmd="$Str1$(printf "%d" $Dist)$Str2"
echo $Cmd
echo $Cmd >>./PBS_Abacus_Creation.bsh
echo "sleep 5" >>./PBS_Abacus_Creation.bsh
echo "wait" >>./PBS_Abacus_Creation.bsh

Dist=$[$Dist+100]
done
